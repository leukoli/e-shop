<?php include("./include/header.inc.php")?>

<div class="container text-center" style="background: red; color:white; font-weight: bold;padding:20px;font-size:30px;">
  商店詳情
</div>

<div class="container text-center">

</div>



<?php include("./include/footer.inc.php")?>
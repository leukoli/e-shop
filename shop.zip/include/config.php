<?php
	
	// define website constant
	define("SITE_ROOT", "/shop/");
	define("SITE_TITLE", "Shop Mall Online");


	// database connection config
	$database = [
		'host' => '192.168.118.121:3307',
		'dbname' => 'mall',
		'username' => 'root',
		'password' => '888@jzy.com',
	];


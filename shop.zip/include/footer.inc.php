		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
		<footer>
			<div class="footer-grids">
				<dl>
					<dt><b>顧客服務</b></dt>
					<dd><a href="<?=SITE_ROOT?>aboutus.php">關於我們</a></dd>
					<dd><a href="<?=SITE_ROOT?>aboutus.php">條款與細則</a></dd>
					<dd><a href="<?=SITE_ROOT?>aboutus.php">私權政策</a></dd>
					<dd><a href="<?=SITE_ROOT?>aboutus.php">運送安裝政策</a></dd>
					<dd><a href="<?=SITE_ROOT?>aboutus.php">退換貨政策</a></dd>
				</dl>
				<dl>
					<dt><b>聯絡我們</b></dt>
					<dd>Whatsapp 查詢 / 5888 5888</dd>
					<dd>E-mail / sales@speed-polyu.edu.hk</dd>
				</dl>
				<dl>
					<dt><b>分店地址</b></dt>
					<dd>PolyU Hung Hom Bay Campus, Hung Hom</dd>
					<dd>PolyU West Kowloon Campus, Yau Ma Tei</dd>
				</dl>
			</div>
			<p class="copyright">Copyright © <?=date("Y")?> <a href="<?=SITE_ROOT?>"><?=SITE_TITLE?></a>. All Rights Reserved.</p>
			<p class="accept-pay">
				<img src="https://shoplineimg.com/621729e6ee0d440013c7df40/62e24bcc03f7930014ded587/1080x.webp?source_format=png">
			</p>
		</footer>
	</body>
</html>